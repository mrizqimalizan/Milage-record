<?php $__env->startSection('content'); ?>
    <!-- <h1>Bootstrap starter template</h1>
    <p class="lead">Use this document as a way to quickly start any new project.<br> All you get is this text and a mostly barebones HTML document.</p> -->
    <?php $__currentLoopData = $mileage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card shadow">
        <div class="card-body">
            <h5 class="card-title"><?php echo e(date_format(date_create($mile->date_drive),'d/m/Y')); ?></h5>
            <h6 class="card-subtitle mb-2 text-muted"><?php echo e($mile->name); ?></h6>
            <p class="card-text"><?php echo e($mile->pur_destination); ?></p>
            <a href="mileage/<?php echo e($mile->id); ?>" class="card-link btn btn-primary btn-sm">More Details</a>
        </div>
    </div>
    <br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\milageProject\resources\views/record_mileage/index.blade.php ENDPATH**/ ?>